jQuery(document).ready(function(){
			jQuery('.bxslider').bxSlider( {
			mode: 'horizontal',
			captions: true,
			minSlides: 1,
			maxSlides: 1,
			adaptiveHeight: true,
			slideWidth: 1090,
			auto: true,
			preloadImages: 'all',
			pause: 5000,
			autoHover: true } );
			});