Thank you for Using Pluto Wordpress Theme.

	i) Pluto Wordpress Theme is Based on the Underscores Framework http://underscores.me/, (C) 2012-2013 Automattic, Inc. 
	ii) Pluto has been created Viaviwebtech.
	iv) It comes GNU General Public License v3. More Details about the License can be found in the license.txt file included in the theme.
	
Image Credits
- screenshot.png: https://unsplash.com.
- nthumb.png: https://unsplash.com.

bxslider
- Released under the MIT license - http://opensource.org/licenses/MIT

Options Framework
- For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. wptheming.com/options-framework-theme/

INSTALL: 
1. Upload the theme by navigating to Appearance > Themes > Install Themes within the WordPress admin. Select the theme zip file to upload.
2. Activate the theme after uploading.
3. Configure and save the theme options within Appearance > Pluto Settings. 

Basic Settings
- Logo: For best results use a Logo of size 360x125px.
- Header Scripts: It is meant to enclose some javascript enclosed within
<script> and </script> tags.
-Footer Scripts: Itis meant to enclose some javascript enclosed within
<script> and </script> tags. But, this will be placed just before the closing
</body> tag. This is ideal for analytics script.
-Copyright Text: This text will be displayed in the left region of the footer.
-Custom CSS: To include some styling to modify colors,width, etc in the
theme. Use this if you have some CSS knowledge. No need to include
<style> and </style> tags. Directly input css.	

Slider Settings
-The Slider is very easy to use. You need to manually input/upload the
images. This slider supports upto 5 Images with a title and URL.
If you wish to use only 3 images, then fill up only the fields corresponding
to the first 3 images, and leave all the others. 

Social Settings
-The Social Settings is relatively easy to configure. Just one thing you need
to take care of is that you need to enter the complete URL for all fields,
except Twitter, where you just need to enter the username.
	 
Everything else used in this theme has been created by me, especially for Pluto theme and is distributed under GPLv3 license.
	